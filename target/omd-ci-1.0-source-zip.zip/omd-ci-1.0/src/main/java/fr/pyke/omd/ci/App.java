package fr.pyke.omd.ci;

/**
 * Hello world.
 *
 */
public class App {
  public static void main(String[] args) {
    System.out.println("Hello World!");
  }

  public static int add(int a, int b) {
    return a + b;
  }

  /*public static int complique(int a, int b) {
    if (a - b == a) {
      a = a;
    } else {
      b = b;
    }
    if (b - a == a) {
      a = a;
    } else {
      b = b;
    }
    return a + b;
  }*/
}
